﻿using System;
using System.Collections.Generic;

namespace Sedna.Service.Requirements.DTO
{
    public partial class RequirementContext : BaseDto
    {
        public int RequirementContextId { get; set; }
        public int RequirementId { get; set; }
        public int ContextId { get; set; }
        public DateTime CreatedTs { get; set; }
        public DateTime UpdatedTs { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }

        public virtual Context Context { get; set; }
        public virtual Requirement Requirement { get; set; }
    }
}
