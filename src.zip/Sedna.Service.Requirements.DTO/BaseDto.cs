﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sedna.Service.Requirements.DTO
{
    public class BaseDto
    {
        private string _username = string.Empty;
        public BaseDto()
        {

        }


    }
}
