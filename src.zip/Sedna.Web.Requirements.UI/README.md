# Sedna Requirements Capture


## Development

Run Project:

```
$ npm run serve
```