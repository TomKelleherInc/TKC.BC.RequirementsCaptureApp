import Vue from 'vue'
import vSelect from 'vue-select'



import SidebarCollapse from './core/sidebar/SidebarCollapse.vue';

Vue.component( 'sidebar-collapse', SidebarCollapse )



export {
  SidebarCollapse
}
