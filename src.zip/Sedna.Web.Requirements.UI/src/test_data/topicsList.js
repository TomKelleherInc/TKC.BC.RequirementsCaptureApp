export const testData_Topics = [
    {
        "topicId": 1,
        "name": "TestData",
        "description": "This is just test data",
        "preferredPhrasing": "This is just test data",
        "requirement": [],
        "subjectTypeTopic": [],
        "topicSearch": []
    }
]