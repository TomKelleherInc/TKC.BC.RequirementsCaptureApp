<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  
}

</script>

<style lang="scss">
@import url('./assets/css/font-awesome.min.css');

@import "./assets/scss/style";

button{
    cursor: pointer;
}
</style>
