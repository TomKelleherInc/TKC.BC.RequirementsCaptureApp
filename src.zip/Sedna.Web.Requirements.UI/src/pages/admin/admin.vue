<template>
    <div>
        <TopicList />
    </div>
</template>

<script>

    //import EventBus from '../../event_bus';
    //import axios from 'axios';
    import '@fortawesome/fontawesome-free/css/all.css'
    import '@fortawesome/fontawesome-free/js/all.js'

    import TopicList from '../../components/topics/topic-list'

export default {
    components: {TopicList},

    data (){
            return {
                TopicList 

            }
        },
        created: function () { 

        },
    
        mounted: function () {            
             
        },


        methods: {
        }
}
</script>

<style scoped>

</style>